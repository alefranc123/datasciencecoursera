x<- 7
repeat {
  if (x > 9) break 
  else { 
    cat(x, "\n")
    x<- x+1
  }
}
